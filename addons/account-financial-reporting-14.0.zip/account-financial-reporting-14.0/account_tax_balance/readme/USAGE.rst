Accounting --> Reporting --> Taxes Balance

Select the company, the date range, the target moves and 'open taxes'

.. figure:: /account_tax_balance/static/description/tax_balance.png
